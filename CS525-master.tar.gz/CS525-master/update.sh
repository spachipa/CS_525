git remote add template https://github.com/Swapnil2095/CS525
git fetch template
git merge template/master

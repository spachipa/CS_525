#ifndef DBERROR_H
#define DBERROR_H

#include "stdio.h"


#define PAGE_SIZE 1024
#define FILE_HEADER 128


#define RC_OK 0
#define RC_FILE_NOT_FOUND 1
#define RC_READ_NON_EXISTING_PAGE 2
#define RC_WRITE_FAILED 3
#define RC_NULL_PARAMETER_ERROR 4
#define RC_READ_ERROR 5

#define RC_RM_COMPARE_VALUE_OF_DIFFERENT_DATATYPE 200
#define RC_RM_EXPR_RESULT_IS_NOT_BOOLEAN 201
#define RC_RM_BOOLEAN_EXPR_ARG_IS_NOT_BOOLEAN 202
#define RC_RM_NO_MORE_TUPLES 203
#define RC_RM_NO_PRINT_FOR_DATATYPE 204
#define RC_RM_UNKOWN_DATATYPE 205

#define RC_IM_KEY_NOT_FOUND 300
#define RC_IM_KEY_ALREADY_EXISTS 301
#define RC_IM_N_TO_LAGE 302
#define RC_IM_NO_MORE_ENTRIES 303

typedef int RC;
extern char RC_message[]; 

extern void printError(RC error, char *message);


#endif

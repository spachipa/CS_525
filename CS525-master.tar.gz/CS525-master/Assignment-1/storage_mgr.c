#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <unistd.h>

#include "storage_mgr.h"
#include "dberror.h"

extern int errno ;
extern char RC_message[];

//global declerations
FILE *file = NULL;  
char *new_page = NULL;
char *page_info = NULL;

/*********************** Storage Manager Initialisation  **************************/

void initStorageManager (void)
{
    printf("\n---------------- < Storage Manager Initialised > ------------------\n");
FILE *file = NULL;  
char *new_page = NULL;
char *page_info = NULL;
}

/*********************** create/open/close Page Functions  **************************/
/* manipulating page files */



RC createPageFile (char *file_name)
{
    int i;
    initStorageManager();
//printf("file created");
    /*Change001:  */
	int writeBlocks = 0; //maintaining write count here
	new_page = (char *) calloc(PAGE_SIZE, sizeof(char));  
    page_info = (char *) calloc(FILE_HEADER, sizeof(char));
    file = fopen(file_name, "w+b");  /* opening file in write mode */ 
      

    for (i=0; i < PAGE_SIZE; i++)
   {// printf("in for:::");
        new_page[i] == '\0';

     	  if(i < FILE_HEADER)
        {//printf("in if:::");
            page_info[i] == '\0';
        }

    }

    strcat(page_info,"1\n");

	
    fwrite(page_info, sizeof(char), FILE_HEADER, file);
    writeBlocks = fwrite(new_page, sizeof(char), PAGE_SIZE, file);
	//int totalbytes = ftell(file);
	//printf("BYTES::: %d", totalbytes);
 //int pages = totalbytes/PAGE_SIZE;
//printf("PAGES::: %d", pages);
	/*Change002:  */ //if nothing is written then returns write fail error
    if(writeBlocks == PAGE_SIZE){
    free(new_page);
    free(page_info);
    fclose(file);

//printf("in if:::%d:::: ",PAGE_SIZE);
    return RC_OK;
    }
    else{
	return RC_WRITE_FAILED;
    }	
}

/*------------------------------------------------------------------------*/

RC openPageFile (char *file_name, SM_FileHandle *fHandle)
{
//printf("file opened");
  //  FILE *file = NULL;
    int error;
    char *page_info,*new_page;
    if(file_name != NULL){
    file = fopen(file_name, "r+b"); /* opening file in read mode */ 
    }
    else{
    return RC_NULL_PARAMETER_ERROR;
    }
    
    if (file != NULL)
    {            

        page_info = (char *) calloc(FILE_HEADER, sizeof(char));
        fgets(page_info, FILE_HEADER, file);
	new_page = (char *) calloc(PAGE_SIZE, sizeof(char));
	fgets(new_page,PAGE_SIZE,file);

	int totalbytes = ftell(file);
	//printf("BYTES2::: %d", totalbytes);
        fHandle->fileName = file_name; 
        fHandle->totalNumPages = atoi(page_info);
        fHandle->curPagePos = 1;
        fHandle->mgmtInfo = file;

	
        free(page_info);
        //fclose(file);   
        return RC_OK;
    }
    else
    {
        //error = errno;
        //fclose(file);
        //fprintf(stderr, "Error opening page file: %s\n", strerror( error ));
        strncpy(RC_message, "RC_FILE_NOT_FOUND in openPageFile function", 200);
        return RC_FILE_NOT_FOUND;
    } 

}

/*------------------------------------------------------------------------*/


RC closePageFile (SM_FileHandle *fHandle)
{

    int result;
  if(fHandle != NULL && fHandle->mgmtInfo != NULL ){
    result= fclose(fHandle->mgmtInfo);
    if(result ==0){
//printf("CLosing File::::::");
      return RC_OK;
    }
    else{
      printf("Errorr1:File Not Found");
      return RC_FILE_NOT_FOUND;
    }
  }
  else{
    printf("Error:NULL parameter error");
    return RC_NULL_PARAMETER_ERROR;
  }
}

/*------------------------------------------------------------------------*/

RC destroyPageFile (char *file_name)
{
    int destroyCheck = -1, error;


    destroyCheck = remove(file_name);
    /* on success destroyCheck ==0 */
    if (destroyCheck == 0)
    {
        return RC_OK;
    }
    else
    { 
        error = errno;
        fprintf(stderr, "Last System Check : %s\n", strerror( error ));
        strncpy(RC_message, "RC_FILE_NOT_FOUND in destroyPageFile function", 200);
        return RC_FILE_NOT_FOUND;
    }
}

/*------------------------------------------------------------------------*/

/***********************  Read Blocks Functions  **************************/
/* reading blocks from disc */

RC readBlock (int pageNum, SM_FileHandle *fHandle, SM_PageHandle memPage)
{
    size_t buffer; // check for need to be free or not
    int seek_page;

    /* check if file is present */

    if (fHandle->mgmtInfo == NULL)
    {
        printf("\n File Not Found");  
        strncpy(RC_message, "RC_FILE_NOT_FOUND in readBlock function", 200);        
        return RC_FILE_NOT_FOUND; 
    }

    /* check for the valid page number */
    if (pageNum > fHandle->totalNumPages || pageNum < 1)
    {
        strncpy(RC_message, "RC_READ_NON_EXISTING_PAGE in readBlock function", 200);        
        return RC_READ_NON_EXISTING_PAGE ;                                                                
    }

    if(pageNum==1)
    {
        seek_page = fseek(fHandle->mgmtInfo,FILE_HEADER, SEEK_SET); 
        printf("\npage no = %d-> flip pinter shift =%d",pageNum,FILE_HEADER);
	return RC_OK;
    }
    else{
    return RC_READ_ERROR;
    }

    if(pageNum>1)
    {
        printf("\npage no = %d-> flip pinter shift =%d",pageNum,((pageNum-1)*PAGE_SIZE)+FILE_HEADER);
        seek_page = fseek(fHandle->mgmtInfo, ((pageNum-1)*PAGE_SIZE)+FILE_HEADER, SEEK_SET);
	return RC_OK;
    } 
	else{
    return RC_READ_ERROR;
    }



    if (seek_page == 0)
    {
        printf("\n ------------Reading page no = %d",pageNum);

        buffer = fread(memPage, sizeof(char), PAGE_SIZE, fHandle->mgmtInfo);
        printf("\n Data in PageBlock =%s",memPage);
        fHandle->curPagePos = pageNum;     //*************      

        return RC_OK;
    }
    else
    {
        printf("\n File Read Error"); 
        strncpy(RC_message, "RC_READ_NON_EXISTING_PAGE in readBlock function", 200);          
        return RC_READ_NON_EXISTING_PAGE;
    }
}

/*------------------------------------------------------------------------*/

int getBlockPos (SM_FileHandle *fHandle)
{
	if(fHandle !=NULL && fHandle->curPagePos >=0){
    return fHandle->curPagePos;
	}else{
    printf("\n NULL ERROR");
	return RC_NULL_PARAMETER_ERROR;
      }
}
/*------------------------------------------------------------------------*/

RC readFirstBlock (SM_FileHandle *fHandle, SM_PageHandle memPage)
{
//printf("Read first Block");
	if(fHandle != NULL){
    return readBlock(1, fHandle, memPage);
	}
	else{printf("PAGE NOT EXIST");
	return RC_READ_NON_EXISTING_PAGE;
	}
}
/*------------------------------------------------------------------------*/

RC readPreviousBlock (SM_FileHandle *fHandle, SM_PageHandle memPage)
{
//printf("Read Previous Block");
	if(fHandle != NULL){
    return readBlock(fHandle->curPagePos-1, fHandle, memPage);
	}
	else{printf("PAGE NOT EXIST");
	return RC_READ_NON_EXISTING_PAGE;
	}
     
}

/*------------------------------------------------------------------------*/

RC readCurrentBlock (SM_FileHandle *fHandle, SM_PageHandle memPage)
{
//printf("Read Current Block");
	if(fHandle != NULL){
    return readBlock(fHandle->curPagePos, fHandle, memPage);
	}
	else{printf("PAGE NOT EXIST");
	return RC_READ_NON_EXISTING_PAGE;
	}
    
}

/*------------------------------------------------------------------------*/

RC readNextBlock (SM_FileHandle *fHandle, SM_PageHandle memPage)
{
//printf("Read next Block");
	if(fHandle != NULL){
    return readBlock(fHandle->curPagePos+1, fHandle, memPage);
	}
	else{printf("PAGE NOT EXIST");
	return RC_READ_NON_EXISTING_PAGE;
	}
    
}
/*------------------------------------------------------------------------*/

RC readLastBlock (SM_FileHandle *fHandle, SM_PageHandle memPage)
{
//printf("Read last Block");
	if(fHandle != NULL){
    return readBlock(fHandle->totalNumPages, fHandle, memPage);
	}
	else{printf("PAGE NOT EXIST");
	return RC_READ_NON_EXISTING_PAGE;
	}
    
}



/***********************  Write Blocks Functions  **************************/
/* writing blocks to a page file */
RC writeBlock (int pageNum, SM_FileHandle *fHandle, SM_PageHandle memPage)
{
    int seek_page,error;
    size_t buffer;
    //char print_str[PAGE_SIZE];
	//printf("CLEAR ::%d",pageNum);
    if (pageNum > (fHandle->totalNumPages) || (pageNum < 1))
    {
        printf("\nNot valid Page1"); 
        error = errno;
        fprintf(stderr, "Last System Check1 : %s\n", strerror( error ));
    
        strncpy(RC_message, "RC_WRITE_FAILED in writeBlock function", 200);         
        return RC_WRITE_FAILED;
    }


    if(pageNum==1)
    {
        seek_page = fseek(fHandle->mgmtInfo, FILE_HEADER, SEEK_SET); 
        printf("\npage no = %d-> flip pointer shift =%d",pageNum,FILE_HEADER);
//return RC_OK;

    }
   // else{
 //   return RC_WRITE_FAILED;
   // }

    if(pageNum>1)
    {
        printf("\npage no = %d-> flip pointer shift =%d",pageNum,((pageNum-1)*PAGE_SIZE)+FILE_HEADER);
        seek_page = fseek(fHandle->mgmtInfo, ((pageNum-1)*PAGE_SIZE)+FILE_HEADER, SEEK_SET); 
//return RC_OK;
    } 
  //  else{
    //return RC_WRITE_FAILED;
    //}

    if (seek_page == 0)
    {

        buffer = fwrite(memPage,sizeof(char), PAGE_SIZE, fHandle->mgmtInfo); 
        fHandle->curPagePos = pageNum;    //*************    

        rewind(fHandle->mgmtInfo);
        fprintf(fHandle->mgmtInfo, "%d\n" , fHandle->totalNumPages);
//printf("CLAERs ::%d",pageNum);
        return RC_OK;
    }
    else
    {

        printf("\nseek_page failed "); 
        
        strncpy(RC_message, "RC_WRITE_FAILED in writeBlock function", 200);          
   
        return RC_WRITE_FAILED;
    }

}


/*------------------------------------------------------------------------*/

RC writeCurrentBlock (SM_FileHandle *fHandle, SM_PageHandle memPage)
{
    int pagePosi; 
    // aditional check introduce if want
    pagePosi=fHandle->curPagePos;
    return writeBlock (pagePosi, fHandle, memPage);

}
/*------------------------------------------------------------------------*/

RC appendEmptyBlock (SM_FileHandle *fHandle)
{
    int i,seek_page,total_pages;
    size_t buffer; 
    char *empty_block;    

    empty_block = (char *) calloc(PAGE_SIZE, sizeof(char)); 

    for (i=0; i < PAGE_SIZE; i++) { 
        empty_block[i] = '\0';
    }

    //empty_block[PAGE_SIZE] == '\0';


    total_pages=fHandle->totalNumPages;
    seek_page = fseek(fHandle->mgmtInfo,0L, SEEK_END); 

    if (seek_page == 0) {

        buffer = fwrite(empty_block,sizeof(char),PAGE_SIZE,fHandle->mgmtInfo); 
        fHandle->totalNumPages = fHandle->totalNumPages + 1;
        fHandle->curPagePos = fHandle->totalNumPages; //*************   


        rewind(fHandle->mgmtInfo);
        fprintf(fHandle->mgmtInfo, "%d\n" , fHandle->totalNumPages); 
//printf("\nAppended: ");
        free(empty_block);
strncpy(RC_message, "RC_OK in appendEmptyBlock complete", 200);
        return RC_OK;

    } else {
        free(empty_block);
        strncpy(RC_message, "RC_WRITE_FAILED in appendEmptyBlock function", 200);          
   
        return RC_WRITE_FAILED;
    }
}
/*------------------------------------------------------------------------*/

RC ensureCapacity (int numberOfPages, SM_FileHandle *fHandle)
{
    int i,requiredPages;

    if (fHandle->totalNumPages < numberOfPages) {
        requiredPages = numberOfPages - fHandle->totalNumPages; 

        for (i=1; i <= requiredPages; i++)
        {
            appendEmptyBlock(fHandle); 
        }
    }

    return RC_OK;
}
/*------------------------------------------------------------------------*/

/* I made changes in readFirstBlock, writeFirstBlock as the previous
WHY? The previous functionalities as the functions are calling readBlock and writeBlock respectively and getting RC_Status in return. This value we are trying to read in the test file "readFirstBlock (&fh, ph)"::(I tried printing the value here, look in the test_assign1_1.c and uncomment, use previous code in readFirstBlock, writeFirstBlock by commenting new code). So, I have changed the functionality as we read it in the same function without any function callings and return values ).

I removed the whole FILE_HEADER part. As that may some times creates 2 pages and can complicate our code. Once we get clear understanding on the program behaviuor we can still add that if we want.  

Error handling issues I added them in every posiible place that I thought. NOW WE HAVE SOME 8 ERROR HANDLING ISSUES, BUT WE CAN STILL KEEP ON ADDING THEM TILL THE LAST MOMENT(it doesnot take much time to do it!!!just identify and define an error)  

The other test cases, I am writing another file for those testcases, I will upload the file once I finished with every test case. Now, our code is perfect with TAs testcase file. 

Documentation: Before every function we can write its description that. 

Look at the code and suggest me any changes needed. 

IGNORE THOSE printf STATEMENTS, I USED THEM FOR MY UNDERSTANDING OF THE FLOW OF PROGRAM.

*/


#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <unistd.h>

#include "storage_mgr.h"
#include "dberror.h"

extern int errno ;
//extern char RC_message[];

//global declerations
FILE *file = NULL;  
char *new_page = NULL;
//char *page_info = NULL;

/*********************** Storage Manager Initialisation  **************************/

void initStorageManager (void)
{
FILE *file = NULL;  
char *new_page = NULL;
//char *page_info = NULL;
}

/*********************** create/open/close Page Functions  **************************/
/* manipulating page files */



RC createPageFile (char *file_name)
{
    int i;
    initStorageManager();
	int writeBlocks = 0; //maintaining write count here
	new_page = (char *) calloc(PAGE_SIZE, sizeof(char));  //initializes value of memory to zero
    //page_info = (char *) calloc(FILE_HEADER, sizeof(char));
    file = fopen(file_name, "w+b");  /* opening file in write mode */ 
      
//------------------------------------------------------------------------------------------------------------
  //  for (i=0; i < PAGE_SIZE; i++)
 //  {// printf("in for:::");
      //  new_page[i] == '\0';

     	//  if(i < FILE_HEADER)
      //  {//printf("in if:::");
          //  page_info[i] == '\0';
       // }

  //  }

  //  strcat(page_info,"1\n");

//I REMOVED THIS BLOCK AS WE ARE WRITING TO THE FILE IN BELOW fwrite, THAT SERVES THE SAME PURPOSE

//----------------------------------------------------------------------------------------------------------

	
   // fwrite(page_info, sizeof(char), FILE_HEADER, file);
    	writeBlocks = fwrite(new_page, sizeof(char), PAGE_SIZE, file);
    if(writeBlocks == PAGE_SIZE){
    free(new_page);
   // free(page_info);
    fclose(file);


    return RC_OK;
    }
    else{
	return RC_WRITE_FAILED;
    }	
}

/*------------------------------------------------------------------------*/

RC openPageFile (char *file_name, SM_FileHandle *fHandle)
{

 initStorageManager();
  //  FILE *file = NULL;
   // int error;
    if(file_name != NULL){
    file = fopen(file_name, "r+"); /* opening file in read mode */ 
    }
    else{
    return RC_NULL_ERROR;
    }
    
    if (file != NULL)
    {            

      //  page_info = (char *) calloc(FILE_HEADER, sizeof(char));
       // fgets(page_info, FILE_HEADER, file);
	//new_page = (char *) calloc(PAGE_SIZE, sizeof(char));
	//fgets(new_page,PAGE_SIZE,file);
	fseek (file, 0, SEEK_END);
	int totalbytes = ftell(file);
	int totalPages= totalbytes/PAGE_SIZE;
	printf("BYTES2::: %d", totalPages);
        fHandle->fileName = file_name; 
        fHandle->totalNumPages = totalPages;
        fHandle->curPagePos = 0;
        fHandle->mgmtInfo = file;

       // free(page_info);
       // fclose(file);   
        return RC_OK;
    }
    else
    {printf("Not Found");
        //error = errno;
        //fclose(file);
        //fprintf(stderr, "Error opening page file: %s\n", strerror( error ));
       // strncpy(RC_message, "RC_FILE_NOT_FOUND in openPageFile function", 200);
        return RC_FILE_NOT_FOUND;
    } 

}

/*------------------------------------------------------------------------*/


RC closePageFile (SM_FileHandle *fHandle)
{

  int result;
  if(fHandle != NULL && fHandle->mgmtInfo != NULL &&(access(fHandle->fileName, W_OK) != -1)){
    result= fclose(fHandle->mgmtInfo);
    if(result ==0){
      return RC_OK;
    }
    else{
      printf("Errorr1:File Not Found");
      return RC_FILE_NOT_FOUND;
    }
  }
  else{
    printf("Error:NULL parameter error");
    return RC_NULL_ERROR;
  }
}

/*------------------------------------------------------------------------*/

RC destroyPageFile (char *file_name)
{
    int destroyCheck = -1, error;


    destroyCheck = remove(file_name);
    /* on success destroyCheck ==0 */
    if (destroyCheck == 0)
    {
        return RC_OK;
    }
    else
    { printf("Destroy file %d",errno);
        error = errno;
        fprintf(stderr, "Last System Check : %s\n", strerror( error ));
        strncpy(RC_message, "RC_FILE_NOT_FOUND in destroyPageFile function", 200);
        return RC_FILE_NOT_FOUND;
    }
}

/*------------------------------------------------------------------------*/

/***********************  Read Blocks Functions  **************************/
/* reading blocks from disc */

RC readBlock (int pageNum, SM_FileHandle *fHandle, SM_PageHandle memPage)
{
	  if(fHandle != NULL){

//printf("page::%dsize::%d||SIZE%d",pageNum,pageNum*PAGE_SIZE,memPage[13]);

    int seekResult,readResult; 
    if(pageNum > fHandle->totalNumPages || pageNum<0){

      printf("Error:Page not exist");
      return RC_READ_NON_EXISTING_PAGE;
    }
    else{

      if(fHandle->mgmtInfo != NULL){
        //rewind(fHandle->mgmtInfo );

        rewind(fHandle->mgmtInfo );
        seekResult = fseek(fHandle->mgmtInfo,PAGE_SIZE,SEEK_SET);    //Here I have removed pageNum in  pageNum*PAGE_SIZE as we are trying to reading from 2nd page then  if(readResult==PAGE_SIZE) below doesnot satisfy and returns READ_ERROR as readressult would be 2*4096 and PAGE_SIZE would be 4096
        if(seekResult ==0){
//printf("pages::%d",memPage[13]);
          readResult = fread(memPage,sizeof(char),PAGE_SIZE,fHandle->mgmtInfo);
//printf("pagesss::%d",memPage[13]);
          //Additional Functionality: Code for if I need to bring the pointer back to starting position
          //rewind(fHandle->mgmtInfo );
          //seekResult = fseek(fHandle->mgmtInfo,pageNum*PAGE_SIZE,SEEK_SET);
          //fHandle->curPagePos=0;
          if(readResult==PAGE_SIZE){
          fHandle->curPagePos=pageNum;
//printf("page::%d",memPage[13]);
          return RC_OK;
          }
          else{

            return RC_READ_ERROR;
          }
        }
        else{

          printf("Error:Page not exist");
          return RC_READ_NON_EXISTING_PAGE;
        }
      }
      else{
        return RC_FILE_NOT_FOUND;
      }
    }
  }
  else{
    printf("Error:NULL parameter error");
    return RC_NULL_ERROR;
  }



  /*  size_t buffer; // check for need to be free or not
    int seek_page;

    /* check if file is present 

    if (fHandle->mgmtInfo == NULL)
    {
        printf("\n File Not Found");  
        strncpy(RC_message, "RC_FILE_NOT_FOUND in readBlock function", 200);        
        return RC_FILE_NOT_FOUND; 
    }

    /* check for the valid page number 
    if (pageNum > fHandle->totalNumPages || pageNum < 1)
    {
        strncpy(RC_message, "RC_READ_NON_EXISTING_PAGE in readBlock function", 200);        
        return RC_READ_NON_EXISTING_PAGE ;                                                                
    }

    if(pageNum==1)
    {
        seek_page = fseek(fHandle->mgmtInfo,0, SEEK_SET); 
        printf("\npage nos = %d->",pageNum);
	return RC_OK;
    }
    else{
    return RC_READ_ERROR;
    }

    if(pageNum>1)
    {
        printf("\npage no = %d-> flip pinter shift =%d",pageNum,((pageNum-1)*PAGE_SIZE)+FILE_HEADER);
        seek_page = fseek(fHandle->mgmtInfo, ((pageNum-1)*PAGE_SIZE)+FILE_HEADER, SEEK_SET);
	return RC_OK;
    } 
	else{
    return RC_READ_ERROR;
    }



    if (seek_page == 0)
    {
        printf("\n ------------Reading page no = %d",pageNum);

        buffer = fread(memPage, sizeof(char), PAGE_SIZE, fHandle->mgmtInfo);
        printf("\n Data in PageBlock =%s",memPage);
        fHandle->curPagePos = pageNum;     //*************      

        return RC_OK;
    }
    else
    {
        printf("\n File Read Error"); 
        strncpy(RC_message, "RC_READ_NON_EXISTING_PAGE in readBlock function", 200);          
        return RC_READ_NON_EXISTING_PAGE;
    }*/
}

/*------------------------------------------------------------------------*/

int getBlockPos (SM_FileHandle *fHandle)
{
	if(fHandle !=NULL && fHandle->curPagePos >=0){
    return fHandle->curPagePos;
	}else{
    printf("\n NULL ERROR");
	return RC_NULL_ERROR;
      }
}
/*------------------------------------------------------------------------*/

RC readFirstBlock (SM_FileHandle *fHandle, SM_PageHandle memPage)
{
//printf("Read first Block");


// I HAVE CHANGED THIS FUNCTION AS THE PREVIOUS ONE IS RETURNING SOME VALUE IN THE MEMORY
if(fHandle != NULL){
  int seekResult,readResult;
    if(fHandle->mgmtInfo != NULL){
        rewind(fHandle->mgmtInfo);
        seekResult = fseek(fHandle->mgmtInfo,0,SEEK_SET);
        if(seekResult ==0){
          readResult = fread(memPage,sizeof(char),PAGE_SIZE,fHandle->mgmtInfo);
          fHandle->curPagePos=0;
          return RC_OK;
        }
        else{
          printf("Error:Page not exist");
          return RC_READ_NON_EXISTING_PAGE;
        }
      }
      else{
        return RC_FILE_NOT_FOUND;
      }
    }
    else{
      return RC_NULL_ERROR;
    }



/*	if(fHandle != NULL){
printf("Mempage::%d",memPage[9]);
    return readBlock(1, fHandle, memPage);
	}
	else{printf("PAGE NOT EXIST");
	return RC_READ_NON_EXISTING_PAGE;
	}*/
}
/*------------------------------------------------------------------------*/

RC readPreviousBlock (SM_FileHandle *fHandle, SM_PageHandle memPage)
{
//printf("Read Previous Block");

	  if(fHandle != NULL){

    int seekResult,readResult; 
int pageNum = (fHandle->curPagePos)-1;
    if(pageNum > fHandle->totalNumPages || pageNum<0){

      printf("Error:Page not exist");
      return RC_READ_NON_EXISTING_PAGE;
    }
    else{

      if(fHandle->mgmtInfo != NULL){
        //rewind(fHandle->mgmtInfo );

        rewind(fHandle->mgmtInfo );
        seekResult = fseek(fHandle->mgmtInfo,pageNum*PAGE_SIZE,SEEK_SET);    
        if(seekResult ==0){
//printf("pages::%d",memPage[13]);
          readResult = fread(memPage,sizeof(char),PAGE_SIZE,fHandle->mgmtInfo);
//printf("pagesss::%d",memPage[13]);
          //Additional Functionality: Code for if I need to bring the pointer back to starting position
          //rewind(fHandle->mgmtInfo );
          //seekResult = fseek(fHandle->mgmtInfo,pageNum*PAGE_SIZE,SEEK_SET);
          //fHandle->curPagePos=0;
          if(readResult==PAGE_SIZE){
          fHandle->curPagePos=pageNum;
//printf("page::%d",memPage[13]);
          return RC_OK;
          }
          else{

            return RC_READ_ERROR;
          }
        }
        else{

          printf("Error:Page not exist");
          return RC_READ_NON_EXISTING_PAGE;
        }
      }
      else{
        return RC_FILE_NOT_FOUND;
      }
    }
  }
  else{printf("999999");
    printf("Error:NULL parameter error");
    return RC_NULL_ERROR;
  }
/*	if(fHandle != NULL){
    return readBlock(fHandle->curPagePos-1, fHandle, memPage);
	}
	else{printf("PAGE NOT EXIST");
	return RC_READ_NON_EXISTING_PAGE;
	}*/
     
}

/*------------------------------------------------------------------------*/

RC readCurrentBlock (SM_FileHandle *fHandle, SM_PageHandle memPage)
{
//printf("Read Current Block");
	if(fHandle != NULL){
    return readBlock(fHandle->curPagePos, fHandle, memPage);
	}
	else{printf("PAGE NOT EXIST");
	return RC_READ_NON_EXISTING_PAGE;
	}
    
}

/*------------------------------------------------------------------------*/

RC readNextBlock (SM_FileHandle *fHandle, SM_PageHandle memPage)
{
//printf("Read next Block");
	if(fHandle != NULL){
    return readBlock(fHandle->curPagePos+1, fHandle, memPage);
	}
	else{printf("PAGE NOT EXIST");
	return RC_READ_NON_EXISTING_PAGE;
	}
    
}
/*------------------------------------------------------------------------*/

RC readLastBlock (SM_FileHandle *fHandle, SM_PageHandle memPage)
{
//printf("Read last Block");
	if(fHandle != NULL){
    return readBlock(fHandle->totalNumPages, fHandle, memPage);
	}
	else{printf("PAGE NOT EXIST");
	return RC_READ_NON_EXISTING_PAGE;
	}
    
}



/***********************  Write Blocks Functions  **************************/
/* writing blocks to a page file */
RC writeBlock (int pageNum, SM_FileHandle *fHandle, SM_PageHandle memPage)
{


// SAME AS READBLOCK 
 int seekResult,writeResult;
  if(pageNum > fHandle->totalNumPages){
    return RC_WRITE_NON_EXISTING_PAGE;
  }
  else if(fHandle == NULL){
    return RC_NULL_ERROR;
  }
  else{
    seekResult = fseek(fHandle->mgmtInfo,pageNum*PAGE_SIZE,SEEK_SET);
    if(seekResult== 0){
      writeResult=fwrite(memPage,sizeof(char), PAGE_SIZE , fHandle->mgmtInfo);
      //seekResult = fseek(fHandle->mgmtInfo,pageNum*PAGE_SIZE,SEEK_SET);
      if(writeResult != PAGE_SIZE){
        return RC_WRITE_FAILED;
      }
      else{
        return RC_OK;
      }
    }
    else{
      return RC_SEEK_FAILURE;
    }
  }
   /* int seek_page,error;
    size_t buffer;
    //char print_str[PAGE_SIZE];
	//printf("CLEAR ::%d",pageNum);
    if (pageNum > (fHandle->totalNumPages) || (pageNum < 0))
    {
        printf("\nNot valid Page1"); 
        error = errno;
        fprintf(stderr, "Last System Check1 : %s\n", strerror( error ));
    
        strncpy(RC_message, "RC_WRITE_FAILED in writeBlock function", 200);         
        return RC_WRITE_FAILED;
    }


    if(pageNum==1)
    {
        seek_page = fseek(fHandle->mgmtInfo, FILE_HEADER, SEEK_SET); 
        printf("\npage no = %d-> flip pointer shift =%d",pageNum,FILE_HEADER);
//return RC_OK;

    }
   // else{
 //   return RC_WRITE_FAILED;
   // }

    if(pageNum>1)
    {
        printf("\npage no = %d-> flip pointer shift =%d",pageNum,((pageNum-1)*PAGE_SIZE)+FILE_HEADER);
        seek_page = fseek(fHandle->mgmtInfo, ((pageNum-1)*PAGE_SIZE)+FILE_HEADER, SEEK_SET); 
//return RC_OK;
    } 
  //  else{
    //return RC_WRITE_FAILED;
    //}

    if (seek_page == 0)
    {

        buffer = fwrite(memPage,sizeof(char), PAGE_SIZE, fHandle->mgmtInfo); 
        fHandle->curPagePos = pageNum;    //*************    

        rewind(fHandle->mgmtInfo);
        fprintf(fHandle->mgmtInfo, "%d\n" , fHandle->totalNumPages);
        return RC_OK;
    }
    else
    {

        printf("\nseek_page failed "); 
        
        strncpy(RC_message, "RC_WRITE_FAILED in writeBlock function", 200);          
   
        return RC_WRITE_FAILED;
    }*/

}


/*------------------------------------------------------------------------*/

RC writeCurrentBlock (SM_FileHandle *fHandle, SM_PageHandle memPage)
{
    int pagePosi; 
    // aditional check introduce if want
    pagePosi=fHandle->curPagePos;
    return writeBlock (pagePosi, fHandle, memPage);

}
/*------------------------------------------------------------------------*/

RC appendEmptyBlock (SM_FileHandle *fHandle)
{
    int i,seek_page,total_pages;
    size_t buffer; 
    char *empty_block;    
//printf("PAGES::%d",fHandle->totalNumPages);
    empty_block = (char *) calloc(PAGE_SIZE, sizeof(char)); 

    for (i=0; i < PAGE_SIZE; i++) { 
        empty_block[i] = '\0';
    }

    //empty_block[PAGE_SIZE] == '\0';


    total_pages=fHandle->totalNumPages;

    seek_page = fseek(fHandle->mgmtInfo,0, SEEK_END); 

    if (seek_page == 0) {

        buffer = fwrite(empty_block,sizeof(char),PAGE_SIZE,fHandle->mgmtInfo); 
        fHandle->totalNumPages = fHandle->totalNumPages + 1;
        fHandle->curPagePos = fHandle->totalNumPages; //*************   


        rewind(fHandle->mgmtInfo);
        fprintf(fHandle->mgmtInfo, "%d\n" , fHandle->totalNumPages); 
        free(empty_block);
//strncpy(RC_message, "RC_OK in appendEmptyBlock complete", 200);     // we are not using this functionality. 
        return RC_OK;

    } else {
        free(empty_block);
        strncpy(RC_message, "RC_WRITE_FAILED in appendEmptyBlock function", 200);          
   
        return RC_WRITE_FAILED;
    }
}
/*------------------------------------------------------------------------*/

RC ensureCapacity (int numberOfPages, SM_FileHandle *fHandle)
{
    int i,requiredPages;

    if (fHandle->totalNumPages < numberOfPages) {
        requiredPages = numberOfPages - fHandle->totalNumPages; 

        for (i=1; i <= requiredPages; i++)
        {
            appendEmptyBlock(fHandle); 
        }
    }

    return RC_OK;
}
/*------------------------------------------------------------------------*/
